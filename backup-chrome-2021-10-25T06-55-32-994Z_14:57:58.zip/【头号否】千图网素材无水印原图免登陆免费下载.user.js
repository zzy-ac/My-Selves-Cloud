// ==UserScript==
// @name             【头号否】千图网素材无水印原图免登陆免费下载
// @namespace        https://www.thfou.com/
// @version          1.0.1.1
// @description      This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author           头号否
// @match            *://www.58pic.com/*
// @match            *://pic.qiantucdn.com/*
// @supportURL       https://www.thfou.com/liuyan
// @compatible	     Chrome
// @compatible	     Firefox
// @compatible	     Edge
// @compatible   	 Safari
// @compatible   	 Opera
// @compatible	     UC
// @license          GPL-3.0-only
// ==/UserScript==
