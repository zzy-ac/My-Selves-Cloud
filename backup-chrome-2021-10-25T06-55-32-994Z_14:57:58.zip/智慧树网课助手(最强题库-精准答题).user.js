// ==UserScript==
// @name         智慧树网课助手(最强题库-精准答题)
// @namespace    qackqi & Stars
// @version      1.0.5.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       qackqi & Stars
// @match        *://*.zhihuishu.com/*
// @connect      qackqi.cn
// @connect      47.98.52.137
// @run-at       document-end
// @grant        unsafeWindow
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// @supportURL   
// @license      MIT
// ==/UserScript==
