// ==UserScript==
// @name         中国大学慕课mooc小工具（稳定题库）
// @namespace    http://wwww.dsw88.club
// @version      2.4.0.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       Cxil
// @run-at       document-start
// @match        *://www.icourse163.org/learn/*
// @match        *://www.icourse163.org/spoc/learn/*
// @grant        GM_xmlhttpRequest
// @grant        GM_notification
// @grant        unsafeWindow
// @license      MIT
// ==/UserScript==
