// ==UserScript==
// @name         自动判超星作业为100分
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  自动填充超星批改作业中的分值100，并提交下一份
// @author       pu
// @match        https://mooc1.chaoxing.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
  console.log('zhixingzhong....');
     //alert("123");
  //  $('#tmpscore').appendTo(123);
    var divA = document.getElementById("tmpscore");
    divA.value=100;
  //  document.getElementsByClassName("test");
    pigai(0);

    //divA.innerHTML = divA.innerHTML+'123';
    // Your code here...
})();