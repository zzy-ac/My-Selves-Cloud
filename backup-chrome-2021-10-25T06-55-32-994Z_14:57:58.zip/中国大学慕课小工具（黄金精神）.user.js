// ==UserScript==
// @name         中国大学慕课小工具（黄金精神）
// @namespace    https://github.com/CodFrm/cxmooc-tools
// @version 2.4.0.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       CodFrm
// @run-at       document-start
// @match        *://www.icourse163.org/learn/*
// @match        *://www.icourse163.org/spoc/learn/*
// @grant        GM_xmlhttpRequest
// @grant        GM_notification
// @grant        unsafeWindow
// @license      MIT
// ==/UserScript==
