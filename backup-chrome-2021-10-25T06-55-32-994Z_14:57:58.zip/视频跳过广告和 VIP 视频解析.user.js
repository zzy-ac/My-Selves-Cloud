// ==UserScript==
// @name              视频跳过广告和 VIP 视频解析
// @name:en           Kill ADs and Watch VIP Videos
// @namespace         http://mofiter.com/
// @version           1.6.0.1
// @description       This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @description:en    maybe it's the most similar VIP videos script to origin website
// @author            mofiter
// @match             *://v.qq.com/x/cover/*
// @match             *://v.qq.com/x/page/*
// @match             *://www.iqiyi.com/v*
// @match             *://v.youku.com/v_show/*
// @match             *://www.mgtv.com/b/*
// @match             *://tv.sohu.com/v/*
// @match             *://film.sohu.com/album/*
// @match             *://www.le.com/ptv/vplay/*
// @match             *://video.tudou.com/v/*
// @match             *://v.pptv.com/show/*
// @grant             unsafeWindow
// @grant             GM_openInTab
// @grant             GM.openInTab
// @grant             GM_getValue
// @grant             GM.getValue
// @grant             GM_setValue
// @grant             GM.setValue
// @grant             GM_registerMenuCommand
// ==/UserScript==
