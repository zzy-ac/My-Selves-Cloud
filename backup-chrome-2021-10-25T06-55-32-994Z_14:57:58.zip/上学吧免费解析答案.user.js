// ==UserScript==
// @name         上学吧免费解析答案
// @namespace    https://letogther.cn/
// @version      1.0
// @description  上学问题一键查询，快速解决所遇到的问题!
// @author       Letogther.CN
// @match        *://*.shangxueba.com/*
// @icon         https://www.shangxueba.com/favicon.ico
// @grant        none
// ==/UserScript==

(function() {
	var jianjie="<li>此码为红包码，限支付宝用户领取，<a href='https://letogther.cn/file/1571.html' target='_blank'>「红包使用方法」</a></li><li>扫一扫领取支付宝红包，万一是大红包呢！</li>";
	var sign="http://zhannei.baidu.com/cse/search?s=15172883906289933777&entry=1&q=";
	var wpqr="https://letogther.cn/collection/wp-qr.php?text=";
	var hbao="RPc1x04837usjvxamuuhzfv56ZHb";
	var mhid="5kfBXlvszp0hMHcnKdVWO6g";
	var tit=document.title;
    tit=tit.replace(" - 上学吧找答案","");
	var wturl='http://zhannei.baidu.com/cse/search?s=15172883906289933777&entry=1&q=';
	var tishi='<hr><p><b>温馨提示：</b>点击上方“免费查看答案”按钮，会带你搜索相关资源，如果未能找到，可多次点击按钮，给你最接近的结果！</p><hr><h2>更多免费习题答案请关注一同学习：</h2><a href="https://letogther.cn/a" target="_blank">https://www.letogther.cn</a><br><img width="300" height="300" src="'+wpqr+hbao+'&mhid='+mhid+'">'+jianjie;
	var	p_html='<div id="codeimage" class="gai_answer_im" style="background-color: #F8F8F8"><div class="gai_answer_i"></div><div class="zjbtndiv"><a href="'+wturl+tit+'" class="zjbtn" id="zjbtn" target="_blank">免费查看答案</a>'+tishi+'</div>';
	var	m_html='<div class="best_answer_g"><div class="best_answer_bg"><div class="s_content" id="zuijiadiv"></div><div class="s_content"><a href="'+wturl+tit+'" class="zjbtn" style="margin-top:0rem;" target="_blank">免费查看答案</a>'+tishi+'</div></div></div>';
	if (document.getElementById("codeimage")){
		document.getElementById("codeimage").innerHTML=p_html;
	}
	if (document.getElementById("Panel_zuijia")){
		document.getElementById("Panel_zuijia").innerHTML=m_html;
	}
})();